package com.example.es03.Modelo;

public class Manga {
    private String uid;
    private String nombre;
    private String autor;
    private String fecha;
    private String demografia;
    private String genero;
    private String tipo;
    private String paginas;

    public Manga() {

    }
//region Setter

    public void setUid(String uid) {
        this.uid = uid;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public void setDemografia(String demografia) {
        this.demografia = demografia;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public void setPaginas(String paginas) {
        this.paginas = paginas;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    //endregion

    //region Getter

    public String getUid() {
        return uid;
    }

    public String getNombre() {
        return nombre;
    }

    public String getAutor() {
        return autor;
    }

    public String getFecha() {return fecha;}

    public String getDemografia() {return demografia;}

    public String getGenero() {return genero;}

    public String getTipo() {return tipo;}

    public String getPaginas() {return paginas;}

// endregion

    @Override
    public String toString() {
        return nombre + "-" + autor + "(" + fecha +")";
    }
}


