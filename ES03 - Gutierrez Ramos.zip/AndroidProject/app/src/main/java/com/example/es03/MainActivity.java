package com.example.es03;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioGroup;
import android.widget.Toast;
import android.widget.ToggleButton;

import com.example.es03.Modelo.Manga;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.UUID;

public class MainActivity extends AppCompatActivity{
    private EditText etNombreM, etAutorM, etFecha, etGenero, etPaginas;
    private ListView lvMangas;
    private ToggleButton toggleTipo;
    private RadioGroup demoGroup;
    private String demo_Str, tipo_Str;

    private DatabaseReference databaseReference;
    private ArrayList<Manga> listaMangas = new ArrayList<>();
    private ArrayAdapter<Manga> mangasArrayAdapter;
    private Manga mangaSeleccionado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        etNombreM= findViewById(R.id.txt_nombreManga);
        etAutorM =  findViewById(R.id.txt_autorManga);
        etFecha = findViewById(R.id.txt_fechaManga);
        demoGroup =  findViewById(R.id.radDemo);
        toggleTipo = findViewById(R.id.toggle_Tipo);
        etGenero = findViewById(R.id.txt_generosManga);
        etPaginas = findViewById(R.id.txt_capitulosManga);


        lvMangas=(ListView) findViewById(R.id.lv_datosMangas);

        iniciarFirebase();
        listarDatos();
        lvMangas.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                mangaSeleccionado = (Manga) adapterView.getItemAtPosition(i);

                etNombreM.setText(mangaSeleccionado.getNombre());
                etAutorM.setText(mangaSeleccionado.getAutor());
                etFecha.setText(mangaSeleccionado.getFecha());
                etGenero.setText(mangaSeleccionado.getGenero());
                etPaginas.setText(mangaSeleccionado.getPaginas());
                demo_Str = mangaSeleccionado.getDemografia();
                tipo_Str = mangaSeleccionado.getTipo();


            }
        });

    }

    private void listarDatos() {
        databaseReference.child("Manga").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                listaMangas.clear();
                for(DataSnapshot obj: snapshot.getChildren())
                {
                    Manga manga = obj.getValue(Manga.class);
                    listaMangas.add(manga);
                }
                mangasArrayAdapter = new ArrayAdapter<>(MainActivity.this,
                        android.R.layout.simple_list_item_1, android.R.id.text1, listaMangas);
                lvMangas.setAdapter(mangasArrayAdapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    private void iniciarFirebase() {
        FirebaseApp.initializeApp(this);
        FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.menu_main,menu);
        return super.onCreateOptionsMenu(menu);
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        String nombre=etNombreM.getText().toString();
        String autor=etAutorM.getText().toString();
        String fecha=etFecha.getText().toString();
        String genero=etGenero.getText().toString();
        String paginas=etPaginas.getText().toString();
        getDemo();
        ToggleTipo();
        String demografia= demo_Str;
        String tipo = tipo_Str;

        switch (item.getItemId())
        {
            case R.id.icon_add:

                if (validacion())

                {

                    Manga manga = new Manga();
                    manga.setUid(UUID.randomUUID().toString());
                    manga.setNombre(nombre);
                    manga.setAutor(autor);
                    manga.setFecha(fecha);
                    manga.setGenero(genero);
                    manga.setPaginas(paginas);
                    manga.setDemografia(demografia);
                    manga.setTipo(tipo);

                    databaseReference.child("Manga").child(manga.getUid()).setValue(manga);
                    Limpiar();
                    Toast.makeText(this, "Agregado", Toast.LENGTH_SHORT).show();

                }
                break;
            case R.id.icon_delete:

                Manga mangaa = new Manga();
                mangaa.setUid(mangaSeleccionado.getUid());
                databaseReference.child("Manga").child(mangaa.getUid()).removeValue();
                Limpiar();
                Toast.makeText(this, "Eliminado", Toast.LENGTH_SHORT).show();
                break;

            case R.id.icon_save:
                Manga manga = new Manga();
                manga.setUid(mangaSeleccionado.getUid());
                manga.setNombre(mangaSeleccionado.getNombre());
                manga.setAutor(mangaSeleccionado.getAutor());
                manga.setFecha(mangaSeleccionado.getFecha());
                manga.setGenero(mangaSeleccionado.getGenero());
                manga.setPaginas(mangaSeleccionado.getPaginas());
                manga.setDemografia(mangaSeleccionado.getDemografia());
                manga.setTipo(mangaSeleccionado.getTipo());

                databaseReference.child("Manga").child(manga.getUid()).setValue(manga);
                Limpiar();

                Toast.makeText(this, "Actualizado:" +mangaSeleccionado.getNombre(), Toast.LENGTH_SHORT).show();
                break;
        }
        return true;
    }

    private boolean validacion()
    {
        if (etNombreM.getText().toString().equals(""))
        {
            etNombreM.setError(("Requerido"));
            return false;
        }
        if (etAutorM.getText().toString().equals(""))
        {
            etAutorM.setError(("Requerido"));
            return false;
        }
        if (etFecha.getText().toString().equals(""))
        {
            etFecha.setError(("Requerido"));
            return false;
        }
        if (etGenero.getText().toString().equals(""))
        {
            etGenero.setError(("Requerido"));
            return false;
        }
        if (etPaginas.getText().toString().equals(""))
        {
            etPaginas.setError(("Requerido"));
            return false;
        }
        if (demo_Str.equals(""))
        {
            return false;
        }
        return true;
    }
    private void Limpiar()
    {
        etNombreM.setText("");
        etAutorM.setText("");
        etFecha.setText("");
        etGenero.setText("");
        etPaginas.setText("");

    }

    private void ToggleTipo()
    {
        toggleTipo = findViewById(R.id.toggle_Tipo);
        if (toggleTipo.isChecked())
        {
            tipo_Str = "Manhwa";
        }
        else
        {
            tipo_Str = "Manga";
        }
    }

    @SuppressLint("NonConstantResourceId")
    private void getDemo() {

        demoGroup =  findViewById(R.id.radDemo);

        if (demoGroup.getCheckedRadioButtonId() == -1)
        {
            demo_Str = "";
            Toast.makeText(this, "Demografia no seleccionada", Toast.LENGTH_SHORT).show();
        }
        else {
            int id = demoGroup.getCheckedRadioButtonId();
            switch (id) {
                case R.id.radShonen:
                    demo_Str = "Shonen";
                    break;
                case R.id.radShoujo:
                    demo_Str = "Shoujo";
                    break;
                case R.id.radSeinen:
                    demo_Str = "Seinen";
                    break;
            }
        }
    }
}
